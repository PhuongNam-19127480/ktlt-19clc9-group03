#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

using namespace std;

struct StudentFromCSV {
	string No;
	string ID;
	string Lastname;
	string Firstname;
	string Gender;
	string Day;
	string Month;
	string Year;
	string DoB;
	string Password;
};

struct Node {
	StudentFromCSV Info;
	Node* next;
};


struct LinkedList {
	Node* head;
	Node* tail;
	int count;
	string ClassName;
};

Node* CreateNode(string No, string ID, string Lastname, string Firstname, string Gender, string Day, string Month, string Year);
void LoadStudent(ifstream& finput, LinkedList& Stu);
void Load_Option(LinkedList& CLC1, LinkedList& CLC2, LinkedList& CLC3, LinkedList& CLC4, LinkedList& CLC5, LinkedList& CLC6, LinkedList& CLC7, LinkedList& CLC8, LinkedList& CLC9, LinkedList& CLC10, LinkedList& APCS1, LinkedList& APCS2);
void InsertStudent(LinkedList& Stu);
void EditStudent(LinkedList& Stu);
void Delete_Student(LinkedList& Class);
void SaveStudentFile(LinkedList Stu);
void OuputStudentList(LinkedList Stu);
void Insert_Option(LinkedList& CLC1, LinkedList& CLC2, LinkedList& CLC3, LinkedList& CLC4, LinkedList& CLC5, LinkedList& CLC6, LinkedList& CLC7, LinkedList& CLC8, LinkedList& CLC9, LinkedList& CLC10, LinkedList& APCS1, LinkedList& APCS2);
void Edit_Option(LinkedList& CLC1, LinkedList& CLC2, LinkedList& CLC3, LinkedList& CLC4, LinkedList& CLC5, LinkedList& CLC6, LinkedList& CLC7, LinkedList& CLC8, LinkedList& CLC9, LinkedList& CLC10, LinkedList& APCS1, LinkedList& APCS2);
void View_Class_List(LinkedList CLC1, LinkedList CLC2, LinkedList CLC3, LinkedList CLC4, LinkedList CLC5, LinkedList CLC6, LinkedList CLC7, LinkedList CLC8, LinkedList CLC9, LinkedList CLC10, LinkedList APCS1, LinkedList APCS2);
void View_Student_List_Option(LinkedList CLC1, LinkedList CLC2, LinkedList CLC3, LinkedList CLC4, LinkedList CLC5, LinkedList CLC6, LinkedList CLC7, LinkedList CLC8, LinkedList CLC9, LinkedList CLC10, LinkedList APCS1, LinkedList APCS2);
void Delete_Option(LinkedList& CLC1, LinkedList& CLC2, LinkedList& CLC3, LinkedList& CLC4, LinkedList& CLC5, LinkedList& CLC6, LinkedList& CLC7, LinkedList& CLC8, LinkedList& CLC9, LinkedList& CLC10, LinkedList& APCS1, LinkedList& APCS2);
void Change_Class_Option(LinkedList& CLC1, LinkedList& CLC2, LinkedList& CLC3, LinkedList& CLC4, LinkedList& CLC5, LinkedList& CLC6, LinkedList& CLC7, LinkedList& CLC8, LinkedList& CLC9, LinkedList& CLC10, LinkedList& APCS1, LinkedList& APCS2);
void Add_Student_To_Class(LinkedList& Stu, LinkedList TempList);
void Delete_Student_From_Class(LinkedList& Class, LinkedList& TempList);
