#include "Header.h"

int main() {
	LinkedList CLC1, CLC2, CLC3, CLC4, CLC5, CLC6, CLC7, CLC8, CLC9, CLC10, APCS1, APCS2;
	string choice;

	while (true) {
		cout << "6. Load student from class" << endl;
		cout << "7. Insert student to a class" << endl;
		cout << "8. Edit a student" << endl;
		cout << "9. Remove a student" << endl;
		cout << "10. Change class" << endl;
		cout << "11. View list of classes " << endl;
		cout << "12. View list of students in a class" << endl;
		cout << "0. Exit" << endl;
		cout << endl;

		cout << "Your choice: ";
		cin >> choice;
		cout << endl;

		if (choice == "6") {
			cout << "6. Load student from class" << endl;
			Load_Option(CLC1, CLC2, CLC3, CLC4, CLC5, CLC6, CLC7, CLC8, CLC9, CLC10, APCS1, APCS2);
			cout << endl;
		}
		else if (choice == "7") {
			cout << "7. Insert student to a class" << endl;
			Insert_Option(CLC1, CLC2, CLC3, CLC4, CLC5, CLC6, CLC7, CLC8, CLC9, CLC10, APCS1, APCS2);
			cout << endl;
		}
		else if (choice == "8") {
			cout << "8. Edit an existing student" << endl;
			Edit_Option(CLC1, CLC2, CLC3, CLC4, CLC5, CLC6, CLC7, CLC8, CLC9, CLC10, APCS1, APCS2);
			cout << endl;
		}
		else if (choice == "9") {
			cout << "9. Remove a student" << endl;
			Delete_Option(CLC1, CLC2, CLC3, CLC4, CLC5, CLC6, CLC7, CLC8, CLC9, CLC10, APCS1, APCS2);
			cout << endl;
		}
		else if (choice == "10") {
			cout << "10. Change class" << endl;
			Change_Class_Option(CLC1, CLC2, CLC3, CLC4, CLC5, CLC6, CLC7, CLC8, CLC9, CLC10, APCS1, APCS2);
			cout << endl;
		}
		else if (choice == "11") {
			cout << "11. View list of class" << endl;
			View_Class_List(CLC1, CLC2, CLC3, CLC4, CLC5, CLC6, CLC7, CLC8, CLC9, CLC10, APCS1, APCS2);
			cout << endl;
		}
		else if (choice == "12") {
			cout << "12. View list of students in a class" << endl;
			View_Student_List_Option(CLC1, CLC2, CLC3, CLC4, CLC5, CLC6, CLC7, CLC8, CLC9, CLC10, APCS1, APCS2);
			cout << endl;
		}
		else if (choice == "0") {
			cout << "Exiting" << endl;
			break;
		}
		else {
			cout << "Incorrect" << endl;
		}
	}	
	return 0;
}
